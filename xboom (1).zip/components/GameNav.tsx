import React from 'react';

const GameNav: React.FC = () => {
  return null;
};

export default GameNav;
