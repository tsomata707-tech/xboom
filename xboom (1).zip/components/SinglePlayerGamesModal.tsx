import React from 'react';

const SinglePlayerGamesModal: React.FC = () => {
  return null;
};

export default SinglePlayerGamesModal;