import React from 'react';
const ThreeCardMonteGame: React.FC = () => null;
export default ThreeCardMonteGame;
