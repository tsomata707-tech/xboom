import React from 'react';
const XCrashGame: React.FC = () => null;
export default XCrashGame;
