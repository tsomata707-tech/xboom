import React from 'react';
const GachaMachineGame: React.FC = () => null;
export default GachaMachineGame;
