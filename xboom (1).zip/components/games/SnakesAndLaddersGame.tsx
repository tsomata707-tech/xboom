import React from 'react';
const SnakesAndLaddersGame: React.FC = () => null;
export default SnakesAndLaddersGame;
