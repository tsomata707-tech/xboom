import React from 'react';

const XboomGamesModal: React.FC = () => {
  return null;
};

export default XboomGamesModal;