import React from 'react';

// تم إصلاح هذا الملف الذي كان فارغًا وتسبب في أخطاء بناء.
// هذا الآن مكون نائب صالح.
const XboomGame: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full p-4 text-center">
      <h2 className="text-3xl font-bold text-cyan-400">لعبة Xboom</h2>
      <p className="text-gray-400 mt-2">سيتم إطلاق هذه اللعبة قريبًا!</p>
    </div>
  );
};

export default XboomGame;
