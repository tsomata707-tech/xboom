import React from 'react';
const HorseRacingGame: React.FC = () => null;
export default HorseRacingGame;
