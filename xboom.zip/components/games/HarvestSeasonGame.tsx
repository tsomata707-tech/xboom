import React from 'react';
const HarvestSeasonGame: React.FC = () => null;
export default HarvestSeasonGame;
