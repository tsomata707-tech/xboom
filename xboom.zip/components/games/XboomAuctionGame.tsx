import React from 'react';

const XboomAuctionGame: React.FC = () => {
  return null;
};

export default XboomAuctionGame;
