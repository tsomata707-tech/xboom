import React from 'react';
const NumberWheelGame: React.FC = () => null;
export default NumberWheelGame;
