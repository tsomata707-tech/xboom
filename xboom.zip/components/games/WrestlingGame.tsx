import React from 'react';
const WrestlingGame: React.FC = () => null;
export default WrestlingGame;
