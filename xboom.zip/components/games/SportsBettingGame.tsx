import React from 'react';
const SportsBettingGame: React.FC = () => null;
export default SportsBettingGame;
