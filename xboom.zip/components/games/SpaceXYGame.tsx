import React from 'react';
const SpaceXYGame: React.FC = () => null;
export default SpaceXYGame;
